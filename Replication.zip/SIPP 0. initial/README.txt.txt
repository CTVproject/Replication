***********************************************
** SIPP CONSTRUCTION OF MAIN INTERMEDIATE .DTAs
***********************************************

(c) 2023 Ludo Visschers & Carlos Carrillo-Tudela



______
STEP 0
^^^^^^

SIPP NBER results in the following files:

The SIPP raw data, dct-files and do-files (that label variables, etc.) can be downloaded from 
	https://www.nber.org/research/data/survey-income-and-program-participation-sipp
We express our gratitude to Jean Roth's work on the dct and do files, which are made available 
under GNU GPL license. These are included here, with minor edits 
	- when putting the zipped raw data/dct/do files in one directory, this only needs to be set 
		once in the step0 file

