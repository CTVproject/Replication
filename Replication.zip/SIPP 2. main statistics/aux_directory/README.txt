aux_programs.do collects a number of auxiliary STATA programs.
occspec_fig2_aux.dta contains labels etc (no economic data) that is helpful for drawing figure 2. 